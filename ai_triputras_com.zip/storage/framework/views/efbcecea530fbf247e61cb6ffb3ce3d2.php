

<?php $__env->startSection('title', 'Generate AI Prompt'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Prompt Generator</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('result.prompt')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-1">
                            <label for="subject" class="form-label">Subject:</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <?php $__currentLoopData = $categoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-1">
                                <label for="color" class="form-label"><?php echo e($categori->category); ?> :</label>
                                <select class="form-control" id='<?php echo e($categori->category); ?>' name='<?php echo e($categori->category); ?>' required>
                                    <option value="None">None</option>
                                    <?php $__currentLoopData = $features->where('category', $categori->category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($feature->name); ?>"><?php echo e($feature->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div style="margin-top: 10px">
                            <button type="submit" class="btn btn-primary">Generate Prompt</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\prompt_proj\prompt_generator\resources\views/prompt/generate.blade.php ENDPATH**/ ?>