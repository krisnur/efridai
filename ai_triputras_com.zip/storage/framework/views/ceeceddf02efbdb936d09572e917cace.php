

<?php $__env->startSection('title', 'Generate AI Prompt'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h3>Saved Prompt</h3>
            <div class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $prompts->paginate(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prompt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div style="margin-bottom: 10px">
                        <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                        <div class="d-flex w-100 justify-content-between">
                            <p class="mb-1"><?php echo e($prompt->content); ?></p>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex justify-content-start">
                                <div class="btn btn-success btn-sm" style="margin-right: 10px" onclick="copyToClipboard('<?php echo e($prompt->content); ?>')">Copy</div>
                                <div>
                                    <form method="post" action="<?php echo e(route('saved.prompt.delete', $prompt->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="id" value="<?php echo e($prompt->id); ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </div>
                            </div>
                            
                            <div class="text-right">
                                <small><?php echo e($prompt->created_at->diffForHumans()); ?></small>
                            </div>
                        </div>
                        
                        
                        
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="list-group">
                        <a href="#" class="list-group-item list-group-item-action">No Saved Prompt</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php if(session('success')): ?>
    <script>
        alert("<?php echo e(session('success')); ?>");
    </script>
<?php endif; ?>
<!-- Add JavaScript to handle copy to clipboard functionality -->
<script>
    function copyToClipboard(text) {
        const copyText = document.createElement('input');
        copyText.value = text;
        copyText.setAttribute('readonly', 'true');
        copyText.style.position = 'absolute';
        copyText.style.left = '-9999px';
        document.body.appendChild(copyText);
        copyText.select();
        document.execCommand('copy');
        document.body.removeChild(copyText);
        alert('Prompt copied to clipboard!');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\prompt_proj\prompt_generator\resources\views/prompt/saved.blade.php ENDPATH**/ ?>