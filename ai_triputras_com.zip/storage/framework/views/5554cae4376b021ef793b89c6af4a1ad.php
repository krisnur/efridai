<!-- resources/views/criteria/index.blade.php -->


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Criteria</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('criteria.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control mr-sm-2" placeholder="Search">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(($criteria->currentPage() - 1) * $criteria->perPage() + $loop->index + 1); ?></td>
                                <td><?php echo e($criterion->name); ?></td>
                                <td><?php echo e($criterion->category); ?></td>
                                <td>
                                    <a href="<?php echo e(route('criteria.edit', $criterion)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(route('criteria.destroy', $criterion)); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- Pagination Links -->
                    <div class="d-flex justify-content-center">
                        <?php echo e($criteria->links()); ?>

                    </div>
                    <a href="<?php echo e(route('criteria.create')); ?>" class="btn btn-success mt-3">Add New</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\prompt_proj\prompt_generator\resources\views/criteria/index.blade.php ENDPATH**/ ?>